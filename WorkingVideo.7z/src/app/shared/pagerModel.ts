export interface PagerModel{
     Sort: string
     PageNumber : number,
     PageSize : number,
     StartDate?: Date,
     EndDate?: Date
}