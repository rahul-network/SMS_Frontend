

export interface PatientMessageRequest {
    Content : string;
    SMSPhoneNo : string;
    CellPhone : string ;
    IsRead : boolean;
}