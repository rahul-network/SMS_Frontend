import { AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { VideoCallComponent } from '../..//Video/Call/videoCall.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DatatableFeedService } from 'src/app/datatable-feed.service';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { MessageComponent } from '../../messsage/message.component';
import { DialerAppComponent } from 'src/app/Voice/dialer-app.component';
import {  catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { merge, Observable } from 'rxjs';
import { MatSort, SortDirection } from '@angular/material/sort';
import {MctFormService  } from './service/mct-service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { IComms, LaraHealthHttpDatabase } from 'src/app/main-datatable/detail-data/detail-data.component';
import { MatPaginator } from '@angular/material/paginator';
import { map, startWith, switchMap } from 'rxjs/operators';


export interface PeriodicElement {
    name: string;
    position: number;
    weight: number;
    symbol: string;
  }
  
  const ELEMENT_DATA: PeriodicElement[] = [
    {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
    {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
    {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
    {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
    {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
    {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
    {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
    {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
    {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
    {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
  ];

  
@Component({
  selector: 'mct-form-data',
  templateUrl: './mct-data.component.html',
  styleUrls: ['./mct-data.component.css']
})




export class MctDataComponent implements OnInit {

    
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = ELEMENT_DATA;
    constructor(
        private httpClient: HttpClient,
        private mctFormService: MctFormService) {
      }
      result: any[];
      ngOnInit(): void {
// debugger;
//         this.mctFormService.getMctForms(
//             '1', 'asc', 1, 10).pipe(
//                 startWith({}),
//                 switchMap(() => {
//                   //this.isLoadingResults = true;
//                   return this.mctFormService!.getMctForms(
//                     this.sort.active, this.sort.direction, this.paginator.pageIndex, 10)
//                     .pipe();
//                 }),
//                 map(data => {
//                   if (data === null) {
//                     return [];
//                   }
//                   this.detailDataSourceLength = data.totalCount;
//                   return data.items;
//                 })
//               ).subscribe(data => this.detailDataSource = data);


    }
    ngAfterViewInit() {
        // this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);
        // merge(this.sort.sortChange, this.paginator.page)
        //   .pipe(
        //     startWith({}),
        //     switchMap(() => {
        //       //this.isLoadingResults = true;
        //       return this.mctFormService!.getMctForms(
        //         this.sort.active, this.sort.direction, this.paginator.pageIndex, 10)
        //         .pipe();
        //     }),
        //     map(data => {
        //       if (data === null) {
        //         return [];
        //       }
        //       this.detailDataSourceLength = data.totalRowCount;
        //       return data.items;
        //     })
        //   ).subscribe(data => this.detailDataSource = data);
    
    }
}